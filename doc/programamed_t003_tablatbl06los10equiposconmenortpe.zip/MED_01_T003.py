# MED_01_T003.py
# Tabla TBL.03: "Los 10 equipos con menor TPEF"
# # Archivo de datos: MED_IW69.csv (Posiciones de aviso)
#                     MED_IW39.csv (Órdenes de mantenimiento)
#                     MED_IW47.csv (Notificaciones de órdenes)
#                     MED_IH06.csv (Ubicaciones técnicas)            
#
# Fecha inicio:     04.02.2022.
# Fecha conclusión: 28.02.2022.


##################### Librerías y archivos

from cmath import nan
from difflib import diff_bytes
from pathlib import Path
from numpy import NaN
from pandas.core.frame import DataFrame

CURRENT_PATH = Path(__file__)
WORKING_FILE1 = CURRENT_PATH.parent.joinpath("MED_IW69.csv")
WORKING_FILE2 = CURRENT_PATH.parent.joinpath("MED_IH06.csv")
WORKING_FILE3 = CURRENT_PATH.parent.joinpath("MED_IW39.csv")
WORKING_FILE4 = CURRENT_PATH.parent.joinpath("MED_IW47.csv")

import pandas as pd
import numpy as np
import datetime
from datetime import timedelta

Posic_avisos = pd.read_csv(WORKING_FILE1, sep=";")
Ubic_téc     = pd.read_csv(WORKING_FILE2, sep=";")
Ordenes      = pd.read_csv(WORKING_FILE3, sep=";")
Notif        = pd.read_csv(WORKING_FILE4, sep=";")

# Crear un nuevo df (Fallas) con campos seleccionados.
df_fallas = DataFrame(Posic_avisos, columns = ["Aviso", "Clase de aviso",
         "Ubicac.técnica", "Denominación", "Falla de Equipo", "Inicio avería", 
         "Hora in.avería","MesInic","Repercusión", "Status sistema","Status usuario", 
         "Fin de avería", "Hora fin avería", "Orden"]) 

# Eliminar los duplicados avisos duplicados en pos_avisos.
df_fallas = df_fallas.drop_duplicates(subset="Aviso")

# Crear un nuevo dataframe para órdenes con campos seleccionados.
df_ordenes = DataFrame(Ordenes, columns=['Orden', 'Clase de orden', 'Fe.inic.extrema'])

# Crear un nuevo dataframe con los datos de las ubicaciones técnicas.
UT = DataFrame(Ubic_téc, columns= ['Ubicac.técnica', 'Denominación', 'Perfil catálogo',
                                   'Fabr. Nº-serie'])

# Eliminar las filas sin datos (NaN).
UT = UT.dropna(subset=['Ubicac.técnica'])

# Crear un nuevo dataframe para notificaciones con los datos de las notificaciones.

df_notif = DataFrame(Notif)


##################### Variables generales

# Datos para las estadísticas.
FechaRef = datetime.date(2021, 10, 27)
MesInic = str(FechaRef.year)[2:] + str(FechaRef.month)

# La planta y la fecha de referencias vienen por "Input"
Planta = "DAL"
MesRef = "2110"
MesRef_original = MesRef

# Calcular PER1 y PER2 (Períodos de 1 y 2 años, AAMM, desde la fecha de referencia.)
mes  = int(MesInic[2:4])
anno = int(MesInic[0:2])

for x in range(0, 2):
    for i in range(1, 12):
        mes = mes - 1
        if mes == 0:
            mes = 12
            anno = anno - 1
    if mes < 10:
        mes = "0" + str(mes)
    else:
        mes = str(mes)
    if x == 0:
        PER1 = str(anno) + mes
    else:
        PER2 = str(anno) + mes 
    mes = int(mes) - 1

# Texto para el mes, para efectos de título de la tabla.
Desc_mes = {'01': 'Enero', '02': 'Febrero', '03': 'Marzo', '04': 'Abril',
            '05': 'Mayo', '06': 'Junio', '07': 'Julio', '08': 'Agosto',
            '09': 'Septiembre', '10': 'Octubre', '11': 'Noviembre', '12': 'Diciembre'}

# Crear lista con los últimos 24 meses para efectos de entrada por lista desplegable.
mes  = int(MesInic[2:4])
anno = int(MesInic[0:2])
AAMM = ""
cmes = str(mes)

for i in range(1, 25):
    if mes < 10:
       cmes = "0" + str(mes)
    else:
        cmes = str(mes)
    canno = str(anno)
    AAMM = AAMM + canno + cmes + ","
    mes = mes - 1
    if mes == 0:
        mes = 12
        anno = anno - 1
AAMM = AAMM[:-1]
AAMM = AAMM.rstrip().split(",")

##################### Funciones

# Función para determinar el indicador de falla (FI).
def xfi(ifalla, reperc):
    yfalla = ""
    if reperc == 3 or ifalla == "X":
        yfalla = "X"
        return yfalla

# Función para determinar si el aviso está en el período de 1 año.
def xper1(fecha):
    xper = ""
    if fecha <= MesInic and fecha >= PER1:
        xper = "X"
    return xper

# Función para determinar si el aviso está en el período de 2 años.
def xper2(fecha):
    xper = ""
    if fecha <= MesInic and fecha >= PER2:
        xper = "X"
    return xper

# Esta función coloca un cero a la izquierda para aquellas horas menores a 10.
def ajuste_hora(hora):
    horax = hora[:2]
    min = hora[3:5]
    if horax[-1] == ":":
        horax = "0" + hora[:1]
        min = hora[2:4]
    hora = horax + min
    return hora

# Función que calcula las horas a partir de los strings F_fin + F_ini
def horasx(datex):
    d2 = datetime.datetime(int(datex[4:8]),int(datex[2:4]),
                           int(datex[0:2]),int(datex[8:10]),int(datex[10:12]))    
    d1 = datetime.datetime(int(datex[16:20]),int(datex[14:16]),
                            int(datex[12:14]),int(datex[20:22]),int(datex[22:24]))
    diff = d2 - d1
    days, seconds = diff.days, diff.seconds
    horas = round(days*24 + seconds /3600, 2)
    return horas


# Función que coloca el guión en un TAG, para efectos de presentación.
def tag_guion(xtag):
    for i in range(0, len(xtag)-1):
        guion = i
        if ord(xtag[i]) < 65:
            #print(xtag[i], ord(xtag[i]))
            break
        guion = guion + 1
        TAGG = xtag[:guion] + '-' + xtag[guion:]
    return TAGG

##################### Cuerpo del programa

# NOTA EXPLICATIVA:
#  - El TPEF es igual a Tiempo calendario del período - Tiempo operativo del equipo
#      dividido entre el número de fallas en el período.
#  - El tiempo operativo tiene tres componentes: DT por falla, DT por correctivo programado
#    y DT por manetenimiento preventivo. 
#  - Los tres componentes se calculan en secciones definidas en este programa.

# 1. PREPARACION DE TABLAS.
#   1.1. df_fallas para cálculo de DT por fallas.
#   1.2. df_notif  para cálculo de DT para correctivo programado y preventivo.

# 1.1. df_fallas.
# Crear la columnas: "FI"        Failure indicator.
#                    "MesInic"   Año y mes de inicio de la falla, AAMM.
#                    "PER1"      Período 1 año, últimos 12 meses.
#                    "PER2"      Período 2 año, últimos 24 meses.
#                    "Planta"    Planta a la que corresponde el aviso.

df_fallas["FI"] = df_fallas.apply(lambda x: xfi(x["Falla de Equipo"],
                                         x["Repercusión"]), axis = 1)
df_fallas["MesInic"]   = df_fallas["Inicio avería"].apply(lambda x: x[8:] + x[3:5])
df_fallas["PER1"]      = df_fallas["MesInic"].apply(xper1)
df_fallas["PER2"]      = df_fallas["MesInic"].apply(xper2)
df_fallas["Planta"]    = df_fallas["Ubicac.técnica"].apply(lambda x: x[:3])
df_fallas["Niv_6"]     = df_fallas["Ubicac.técnica"].apply(lambda x: 6 if len(x)>11 else 0)

# 1.2. df_notif.

# Crear las columnas "MesInic", "PER1", "PER2", "Planta" y "Niv_6" con sus respectivo valores.
df_notif["MesInic"]   = df_notif["Fe.in.real"].apply(lambda x: str(x))
df_notif["MesInic"]   = df_notif["MesInic"].apply(lambda x: x[8:] + x[3:5])
df_notif["PER1"]      = df_notif["MesInic"].apply(xper1)
df_notif["PER2"]      = df_notif["MesInic"].apply(xper2)
df_notif["Planta"]    = df_notif["Ubicac. Técnica"].apply(lambda x: x[:3])
df_notif["Niv_6"]     = df_notif["Ubicac. Técnica"].apply(lambda x: 6 if len(x)>11 else 0)

# Dejar las filas para la planta, las no eliminadas y que estén en el período PER2.
df_notif = df_notif[(df_notif['Planta']  == Planta)]
df_notif = df_notif[(df_notif['Eiminar'] != 'X')]
df_notif = df_notif[(df_notif['PER2']    == 'X')]
df_notif = df_notif[(df_notif['Niv_6']   !=  0)]


# Incluir la columna 'FI' en df_notif, antes de que df_fallas sea manipulado.
df_notif = pd.merge(df_notif, df_fallas[['Orden','FI']], on = 'Orden', how = 'outer')

# Eliminar las notificaciones duplicadas generadas por el merge.
# Para eso se requiere un campo 'número de notificación' + 'contador'

df_notif["XNotif"]    = df_notif.apply(lambda x: str((x['Notific.'])) +
                                                     str((x['Contador'])), axis = 1)

df_notif.drop_duplicates(subset='XNotif', inplace = True)
df_notif.sort_values(['Orden'], ascending = False, inplace = True)
df_notif.dropna(subset=['Ubicac. Técnica'], inplace=True)

# Dejar solo las filas que no correspondan a fallas.
df_notif = df_notif[(df_notif['FI'] != 'X')]


# 2. CÁLCULO DT FALLAS.

# Filtrar por planta, PER1, PER2 (PER2 incluye a PER1) y nivel 6.

df_fallas = df_fallas[(df_fallas["Planta"] == Planta) & (df_fallas["FI"] == "X") 
                    & (df_fallas["PER2"] == "X") & (df_fallas["Niv_6"] == 6)]   


# Se podría incluir un "sys.exit" en el caso de que el dataframe resulte vacío.

# Ajustar las horas con un cero a la izquierda para horas menores a 10.
df_fallas["HInic"] = df_fallas["Hora in.avería"].apply(ajuste_hora)

# Crear las columnas F_ini y F_fin como cadena de caracteres ddmmaaaahhmm.
df_fallas["F_ini"] = df_fallas.apply(lambda x: x["Inicio avería"][0:2]  +
                                               x["Inicio avería"][3:5]  +
                                               x["Inicio avería"][6:10] +
                                                x["HInic"], axis = 1)

# Colocar la fecha y hora de inicio de avería en fecha y hora fin de avería cuando
#   esta última sea cero, es decir, cuando la falla todavía esté activa.
# Cuando se reste la (Fecha y hora fin) - (Fecha y hora inicio) dará cero.

# Llenar los valores NaN con cero.
df_fallas = df_fallas.fillna(0)

# Crear un campo transitorio (XHF) para saber cuál aviso originalmente era NaN
df_fallas["XHF"]    = df_fallas["Fin de avería"].apply(lambda x: 0 if x == 0 else 1)

# Si "Fin de avería" es cero, reemplazar con la fecha inicio de avería, sino queda igual.
df_fallas["Fin de avería"] = np.where(df_fallas["Fin de avería"] == 0, 
                                      df_fallas["Inicio avería"], df_fallas["Fin de avería"])

# Si XHF es cero, reemplazar con la hora de inicio de avería, sino queda igual. 
df_fallas["Hora fin avería"] = np.where(df_fallas["XHF"] == 0, 
                                      df_fallas["Hora in.avería"], df_fallas["Hora fin avería"])

# Ajustar las horas con un cero a la izquierda para horas menores a 10.
df_fallas["HFin"]  = df_fallas["Hora fin avería"].apply(ajuste_hora)

# Crear las columnas F_ini y F_fin como cadena de caracteres ddmmaaaahhmm.
df_fallas["F_fin"] = df_fallas.apply(lambda x: x["Fin de avería"][0:2]  +
                                               x["Fin de avería"][3:5]  +
                                               x["Fin de avería"][6:10] +
                                               x["HFin"], axis = 1)   
               
# Calcular la duración del tiempo fuera de servicio (down time).
df_fallas["Dur"] = (df_fallas["F_fin"] + df_fallas["F_ini"]).apply(horasx)

# Separar la duración para 1 año (Dur_1A)
df_fallas['Dur_1A'] = df_fallas.apply(lambda x: x['Dur'] if x['PER1'] == "X" else 0, axis = 1)

# Convierte el "X" de FI en 1 (numérico), para efectos de suma.
df_fallas["FI"] = np.where(df_fallas["FI"] == "X", 1, 0)

# Separar la cantidad de fallas para un año (FI_1A), 'Dur' y 'FI', son para 2A.
df_fallas["FI_1A"] = df_fallas.apply(lambda x: 1 if x['PER1'] == 'X' else 0, axis = 1)

df_fallas = df_fallas.groupby('Ubicac.técnica').sum().reset_index()

# RESULTADO COMPONETES FALLAS: df_fallas:
#    Para 12 meses: 'FI_1A', 'Dur_1A'
#    Para 24 meses: 'FI', 'Dur'



# 2. DT POR CORRECTIVO PROGRAMADO.
#      Corresponde al tiempo de ejecución de órdenes clase PM01 de avisos sin 
#      indicador de falla.


# Ajustar las horas con un cero a la izquierda para horas menores a 10.
df_notif["HInic"] = df_notif["H.in.real"].apply(ajuste_hora)

# Crear las columnas F_ini y F_fin como cadena de caracteres aaammddhhmm.
df_notif["F_ini"] = df_notif.apply(lambda x: x["Fe.in.real"][6:10]  +
                                              x["Fe.in.real"][3:5]  +
                                              x["Fe.in.real"][0:2] +
                                              x["HInic"], axis = 1)

#Ajustar las horas con un cero a la izquierda para horas menores a 10.
df_notif["HFin"] = df_notif["Fin real"].apply(ajuste_hora)

# Crear las columnas F_ini y F_fin como cadena de caracteres aaammddhhmm.
df_notif["F_fin"] = df_notif.apply(lambda x: x["FecFinReal"][6:10]  +
                                               x["FecFinReal"][3:5]  +
                                               x["FecFinReal"][0:2] +
                                               x["HFin"], axis = 1)

######## 
# Calcular la duración del tiempo fuera de servicio (down time) por operación de orden.
# df_notif["Dur"] = (df_notif["F_fin"] + df_notif["F_ini"]).apply(horasx)
########

# Crear una columna nueva con el número actual de fila y convertir la columna en índice.
df_notif['Row_num'] = np.arange(len(df_notif))
df_notif.set_index('Row_num')

df_notif.set_index('Row_num', inplace=True)

i = 0
n = len(df_notif)
xinicio = 0
xorden  = 0
xfin    = 0
while i < n - 1:
    xinicio = df_notif.iloc[i]['F_ini']
    xfin    = df_notif.iloc[i]['F_fin']
    
    if df_notif.iloc[i]['Orden'] == df_notif.iloc[i+1]['Orden']:
        j = i 
        while df_notif.iloc[j]['Orden'] == df_notif.iloc[j+1]['Orden']:
            if  xinicio > df_notif.iloc[j+1]['F_ini']:
                xinicio = df_notif.iloc[j+1]['F_ini']
                                
            if xfin < df_notif.iloc[j+1]['F_fin']:
                xfin = df_notif.iloc[j+1]['F_fin']
 
            j = j + 1
        i = j
    
    df_notif.at[i, 'XINI'] = xinicio
    df_notif.at[i, 'XFIN'] = xfin 

    i = i + 1

if n == i + 1:
    df_notif.at[i, 'XINI'] = df_notif.iloc[i]['F_ini']
    df_notif.at[i, 'XFIN'] = df_notif.iloc[i]['F_fin']

# Eliminar las filas con XINI = NaN, así solo queda la orden con XINI y XFIN.
df_notif.dropna(subset=['XINI'], inplace= True)

# Colocar F_ini y F_fin con los valores de XINI y XFIN con el formato ddmmaaaahhmm.
df_notif['F_ini'] = df_notif['XINI'].apply(lambda x: x[6:8]+x[4:6]+x[:4]+x[8:10]+x[10:12])
df_notif['F_fin'] = df_notif['XFIN'].apply(lambda x: x[6:8]+x[4:6]+x[:4]+x[8:10]+x[10:12])

# Calcular el DT en horas.
df_notif["Dur"] = (df_notif["F_fin"] + df_notif["F_ini"]).apply(horasx)

# Dejar solo las columnas necesarias.
df_notif.drop(['Notific.', 'Contador', 'Op.', 'SOp', 'Fe.in.real',
               'H.in.real', 'FecFinReal', 'Fin real', 'DurReal', 'Un.',
               'Trbjo real', 'UnTrabReal', 'Not.anul', 'Fin', 'PtoTrReal',
               'Status de sistema', 'Eiminar', 'Planta', 'Niv_6', 'FI', 'XNotif',
               'F_ini', 'HFin', 'HInic', 'F_fin', 'XINI', 'XFIN'], axis=1, inplace=True)

# Segregar los DT para correctivos programados y preventivos para 12m y 24 meses.
df_notif['Dur_1AP'] = df_notif.apply(lambda x: x['Dur'] if (x['PER1'] == "X")
                                & (x['ClOrd'] == "PM02") else 0, axis = 1)
df_notif['Dur_1AC'] = df_notif.apply(lambda x: x['Dur'] if (x['PER1'] == "X")
                                & (x['ClOrd'] == "PM01") else 0, axis = 1)
df_notif['Dur_2AP'] = df_notif.apply(lambda x: x['Dur'] if x['ClOrd'] == "PM02"
                                                        else 0, axis = 1)
df_notif['Dur_2AC'] = df_notif.apply(lambda x: x['Dur'] if x['ClOrd'] == "PM01"
                                                        else 0, axis = 1)

# Renombrar la columna 'Ubicac. Técnica' de df_notif para igualarla a la de df_fallas
# y poder hacer el merge.
df_notif.rename(columns={df_notif.columns[2]:'Ubicac.técnica'}, inplace=True)

df_notif = df_notif.groupby(["Ubicac.técnica"]).sum().reset_index()

#print(df_fallas.loc[df_fallas['Ubicac.técnica']=='DAL-LD-ENVA-FL4200A']
#                            [['Ubicac.técnica', 'FI', 'Dur_1A', 'FI_1A']])


# Hacer el merge para colocar los datos fallas, corr. programado y prev en un sola df.
df_TPEF = pd.merge(df_notif, df_fallas, on = 'Ubicac.técnica', how = 'outer')                               

# Calcular el DT y TPEF para 1 y 2 años.
df_TPEF['DT_1A'] = df_TPEF.apply(lambda x: (8760-x['Dur_1A']+x['Dur_1AC']+x['Dur_1AP']), axis = 1)
df_TPEF['DT_2A'] = df_TPEF.apply(lambda x: (17520-x['Dur_y']+x['Dur_2AC']+x['Dur_2AP']), axis = 1)
df_TPEF['TPEF_1A'] = df_TPEF.apply(lambda x: 8760 if x['FI_1A'] == 0 else
                      (x['DT_1A']/x['FI_1A']), axis = 1)
df_TPEF['TPEF_2A'] = df_TPEF.apply(lambda x: 17520 if x['FI'] == 0 else
                      (x['DT_2A']/x['FI']), axis = 1)

# Dejar solo las columnas necesarias.
df_TPEF.drop(['Orden_x', 'Dur_x', 'Dur_1AP', 'Dur_1AC', 'Dur_2AP',
       'Dur_2AC', 'Aviso', 'Repercusión', 'Orden_y', 'Niv_6', 'XHF',
       'Dur_y', 'Dur_1A', 'DT_1A', 'DT_2A'], axis=1, inplace=True)

df_TPEF.fillna({'FI':0,'FI_1A':0, 'TPEF_1A':8760, 'TPEF_2A':17520}, inplace=True)
df_TPEF['FI']      = df_TPEF['FI'].astype(np.int64)
df_TPEF['FI_1A']   = df_TPEF['FI_1A'].astype(np.int64)
df_TPEF['TPEF_1A'] = round(df_TPEF['TPEF_1A'],2)
df_TPEF['TPEF_2A'] = round(df_TPEF['TPEF_2A'],2)
df_TPEF['Mejora']  = round(df_TPEF.apply(lambda x: (1-(x['TPEF_1A']/x['TPEF_2A']))*100,
                            axis = 1), 0)

# Crear la columna TAG.
df_TPEF["TAG"] = df_TPEF["Ubicac.técnica"].apply(lambda x: x[12:])
df_TPEF["TAG"] = df_TPEF["TAG"].apply(tag_guion)

# Colcar la denominación de la ubicación técnica mediante un merge con UT.
df_TPEF = df_TPEF.merge(UT, on = "Ubicac.técnica")
df_TPEF['Denominación'] = df_TPEF['Denominación'].apply(lambda x: x.ljust(40))

# Jusftificar hacia la izquierda las columnas TAG y Denominación.
df_TPEF['TAG'] = df_TPEF['TAG'].apply(lambda x: x.ljust(10))


##################### Resultado: df_TPEF

# Ordenar ascendentemente por TPEF_1A.
df_TPEF.sort_values(['TPEF_1A'], ascending = True, inplace = True)

#print(df_TPEF[['TAG', 'Denominación','TPEF_1A', 'FI_1A', 'TPEF_2A', 'FI']][:50])
print(df_TPEF[['TAG','TPEF_1A', 'FI_1A', 'TPEF_2A', 'FI', 'Mejora']].head(10))

##################### Fin del programa



#pd.set_option('display.max_rows', df_TPEF.shape[0]+1)
#print(df_TPEF)
#df_TPEF.to_csv("abc.csv")
#print(df_TPEF.loc[df_TPEF['Ubicac.técnica']=='DAL-QP-ENVA-TP1220'])
