# MED_01_T001.py.
# Tablas Tbl.01A y Tbl.01B. "Avisos M3 del mes y últimos 12 meses".
# Fecha finalización: 04.01.2022.

# IMPORTANTE:
# Los campos de fecha deben tener el formato DD/MM/AAAA, 21/9/2021 debe ser 21/09/2021.

from pathlib import Path
from pandas.core.frame import DataFrame

CURRENT_PATH = Path(__file__)
WORKING_FILE_01 = CURRENT_PATH.parent.joinpath("MED_IW69E.csv")
## WORKING_FILE_02 = CURRENT_PATH.parent.joinpath("MED_IW39.csv")

import pandas as pd
import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
import datetime
from datetime import timedelta

# Carga el archivo CSV contentivo de los datos de posiciones de aviso.
Posic_avisos = pd.read_csv(WORKING_FILE_01, sep=";")
## Ordenes = pd.read_csv(WORKING_FILE_02, sep=";")

# Fecha de referencia, viene del usuario. Fecha de toma de los datos.
FechaRef = datetime.date(2021, 10, 27)
MesInic = str(FechaRef.year)[2:] + str(FechaRef.month)

# La planta viene del input del usuario.
Planta = "DAL"

# Mes actual de referencia.
mes_actual  = MesInic[0:2]+MesInic[2:4]

# Calcular PER1 y PER2 (Períodos de 1 y 2 años, AAMM, desde la fecha de referencia.)
mes  = int(MesInic[2:4])
anno = int(MesInic[0:2])
for x in range(0, 2):
    for i in range(1, 12):
        mes = mes - 1
        if mes == 0:
            mes = 12
            anno = anno - 1
    if mes < 10:
        mes = "0" + str(mes)
    else:
        mes = str(mes)
    if x == 0:
        PER1 = str(anno) + mes
    else:
        PER2 = str(anno) + mes 
    mes = int(mes) - 1

# Función para determinar si el aviso está en el período de 1 año.
def xper1(fecha):
    xper = ""
    if fecha <= MesInic and fecha >= PER1:
        xper = "X"
    return xper

# Crea un nuevo df (df_pos_avisos) con campos seleccionados.
df_pos_avisos = DataFrame(Posic_avisos, columns = ["Aviso", "Clase de aviso",
         "Ubicac.técnica","Falla de Equipo", "Inicio avería", "Hora in.avería",
         "MesInic","Repercusión", "Orden", "Status sistema", "Fin de avería",
         "Hora fin avería", "Status usuario"]) 

# Calcular los valores para mes de inicio, período y planta.
df_pos_avisos["MesInic"]   = df_pos_avisos["Inicio avería"].apply(lambda x: x[8:] + x[3:5])
df_pos_avisos["PER1"]      = df_pos_avisos["MesInic"].apply(xper1)
df_pos_avisos["Planta"]    = df_pos_avisos["Ubicac.técnica"].apply(lambda x: x[:3])

df_M3 = df_pos_avisos[(df_pos_avisos["Clase de aviso"] == "M3") &
                      (df_pos_avisos["PER1"] == "X") & (df_pos_avisos["Planta"] == Planta)]

df_M3 = df_M3.drop(df_M3[['Clase de aviso', 'Ubicac.técnica', 'Falla de Equipo', 'PER1',
                          'Orden', 'Repercusión','Planta', 'Aviso', 'Status sistema']], axis = 1)

# Esta función coloca un cero a la izquierda para aquellas horas menores a 10.
def ajuste_hora(hora):
    horax = hora[:2]
    min = hora[3:5]
    if horax[-1] == ":":
        horax = "0" + hora[:1]
        min = hora[2:4]
    hora = horax + min
    return hora

# Ajustar las horas con un cero a la izquierda para horas menores a 10.
df_M3["HInic"] = df_M3["Hora in.avería"].apply(ajuste_hora)
df_M3["HFin"]  = df_M3["Hora fin avería"].apply(ajuste_hora)

# Crear las columnas F_ini y F_fin como cadena de caracteres ddmmaaaahhmm
df_M3["F_ini"] = df_M3.apply(lambda x: x["Inicio avería"][0:2] + x["Inicio avería"][3:5] +
                                       x["Inicio avería"][6:10] + x["HInic"], axis = 1)

df_M3["F_fin"] = df_M3.apply(lambda x: x["Fin de avería"][0:2] + x["Fin de avería"][3:5] +
                                       x["Fin de avería"][6:10] + x["HFin"], axis = 1)

# Función que calcula las horas a partir de los stings F_fin + F_ini
def horasx(datex):
    d2 = datetime.datetime(int(datex[4:8]),int(datex[2:4]),
                           int(datex[0:2]),int(datex[8:10]),int(datex[10:12]))    
    d1 = datetime.datetime(int(datex[16:20]),int(datex[14:16]),
                            int(datex[12:14]),int(datex[20:22]),int(datex[22:24]))
    diff = d2 - d1
    days, seconds = diff.days, diff.seconds
    horas = round(days*24 + seconds /3600, 2)
    return horas

df_M3["Dur"] = (df_M3["F_fin"] + df_M3["F_ini"]).apply(horasx)

df_M3["TEJM"] = df_M3["Status usuario"].apply(lambda x: 1 if (x.find("TEJM") != -1) else 0)
df_M3["TOPE"] = df_M3["Status usuario"].apply(lambda x: 1 if (x.find("TOPE") != -1) else 0)
df_M3["SinI"] = df_M3.apply(lambda x: 1 if x["TEJM"] + x["TOPE"] == 0 else 0, axis = 1) 
df_M3["Dur_TEJM"] = df_M3.apply(lambda x: x["Dur"] if x["TEJM"] == 1 else 0, axis = 1)
df_M3["Dur_TOPE"] = df_M3.apply(lambda x: x["Dur"] if x["TOPE"] == 1 else 0, axis = 1)
df_M3["Dur_SinI"] = df_M3.apply(lambda x: x["Dur"] if x["SinI"] == 1 else 0, axis = 1)

df_M3_12M = df_M3.sum(numeric_only=True)
df_M3_Mes = df_M3[(df_M3["MesInic"] == mes_actual)].sum(numeric_only=True)

# RESULTADO:
#   Tablas Tbl.01A está en el dataframe df_M3_Mes.
#   Tablas Tbl.01B está en el dataframe df_M3_12M.

print(df_M3_Mes)  
print(df_M3_12M)  


