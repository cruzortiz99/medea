# MED_01_004.py.
# Gráfica GRF.04.
# Cantidad de fallas por planta, con paro y limitaciób de producción.

from pathlib import Path
from pandas.core.frame import DataFrame

CURRENT_PATH = Path(__file__)
WORKING_FILE = CURRENT_PATH.parent.joinpath("MED_IW69.csv")

import pandas as pd
import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np

import datetime
from datetime import timedelta

Posic_avisos = pd.read_csv(WORKING_FILE, sep=";")

# Datos para las estadísticas
FechaRef = datetime.date(2021, 10, 27)
MesInic = str(FechaRef.year)[2:] + str(FechaRef.month)

# Calcular PER1 y PER2 (Períodos de 1 y 2 años, AAMM, desde la fecha de referencia.)
mes  = int(MesInic[2:4])
anno = int(MesInic[0:2])

for x in range(0, 2):
    for i in range(1, 12):
        mes = mes - 1
        if mes == 0:
            mes = 12
            anno = anno - 1
    if mes < 10:
        mes = "0" + str(mes)
    else:
        mes = str(mes)
    if x == 0:
        PER1 = str(anno) + mes
    else:
        PER2 = str(anno) + mes 
    mes = int(mes) - 1

# Crear valor para eje de las x (meses) en gráficas de 12 meses.
#   Salida: Una serie AAMM (AA: dos últimos dígitos del año, MM: mes numérico).
# Esto es necesario para asegurar que aparezcan los últimos 12 meses aun cuando no hayan datos
# en alguno de los meses.

mes  = int(MesInic[2:4])
anno = int(MesInic[0:2])

AAMM = ""
cmes = str(mes)

for i in range(1, 13):
    if mes < 10:
       cmes = "0" + str(mes)
    else:
        cmes = str(mes)
    canno = str(anno)
    AAMM = AAMM + canno + cmes + ","
    mes = mes - 1
    if mes == 0:
        mes = 12
        anno = anno - 1
AAMM = AAMM[:-1]
AAMM = AAMM.rstrip().split(",")
AAMM = list(reversed(AAMM))


# La planta y la fecha de referencias vienen por "Input"
Planta = "DAL"
## print(FechaRef, MesInic, Planta)

# Función para determinar el indicador de falla (FI).
def xfi(ifalla, reperc):
    yfalla = ""
    if reperc == 3 or ifalla == "X":
        yfalla = "X"
        return yfalla

# Función para determinar si el aviso está en el período de 1 año.
def xper1(fecha):
    xper = ""
    if fecha <= MesInic and fecha >= PER1:
        xper = "X"
    return xper

# Función que convierte AAMM en letras Mmm y coloca el 'AA si es enero ("Jan").
def mesletras(xmes):
    Mmm = datetime.date(int("20"+xmes[:2]), int(xmes[2:4]), 1).strftime("%b")
    if Mmm == "Jan":
        Mmm = Mmm+"'"+xmes[:2]
    return Mmm

# Crea un nuevo df (Fallas) con campos seleccionados, más uno nuevo ("FI" - indicador
#     de falla, "Planta" y "PER1" - período de 1 año.)

df_fallas = DataFrame(Posic_avisos, columns = ["Aviso", "Ubicac.técnica", 
         "Falla de Equipo", "Inicio avería", "MesInic", "Repercusión", "FI", "Planta",
          "PER1"]) 

# Columna FI
df_fallas["FI"] = df_fallas.apply(lambda x: xfi(x["Falla de Equipo"],
                                         x["Repercusión"]), axis = 1)

df_fallas["MesInic"]   = df_fallas["Inicio avería"].apply(lambda x: x[8:] + x[3:5])
df_fallas["PER1"]      = df_fallas["MesInic"].apply(xper1)
df_fallas["Planta"]    = df_fallas["Ubicac.técnica"].apply(lambda x: x[:3])

# Para la planta especificada en la variable "Planta" (que debe venir por input) y 
#   período de 1 año.
df_fallas = df_fallas[(df_fallas["Planta"] == Planta) & (df_fallas["PER1"] == "X") & 
                      (df_fallas["Repercusión"] > 1) & (df_fallas["FI"] == "X")]

# Agregar las columnas R3 y R2 y colocarle 1 según la repercusión
df_fallas["R3"] = df_fallas["Repercusión"].apply(lambda x: 1 if x == 3 else 0 )
df_fallas["R2"] = df_fallas["Repercusión"].apply(lambda x: 1 if x == 2 else 0 )

# dataframe para la gráfica de fallas por mes (últimos 12 meses).
df_fallas = df_fallas.groupby(["MesInic"]).sum().reset_index()

# Agregar la columna "Tot" con el total de R2 + R3
df_fallas["Tot"] = df_fallas.apply(lambda x: x["R3"] + x["R2"], axis = 1)

# Dejando solo las columnas a graficar.
df_fallas = df_fallas.drop(['Aviso', 'Repercusión'], axis=1)

# Crear la columna "MesL", mes en letras.
df_fallas["MesL"]    = df_fallas["MesInic"].apply(mesletras)

total_fallas_R2 = df_fallas["R2"].sum()
total_fallas_R3 = df_fallas["R3"].sum()
promedio_R2_R3  = np.round(df_fallas["Tot"].mean(), 1)
desv_standard   = np.round(df_fallas["Tot"].std(), 1)


###### Preparación para graficar la tabla df_fallas.

# Esto convierte el contenido de dataframe en listas (para poder graficar)
Mes_c = []
R3X = []
R2X = []
TotX = []

for i in range(len(df_fallas)):
    Mes_c = Mes_c + [df_fallas["MesInic"][i]]
    R3X = R3X + [int(df_fallas["R3"][i])]
    R2X = R2X + [int(df_fallas["R2"][i])]
    TotX = TotX + [int(df_fallas["Tot"][i])]

N = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
def month_filling(mesx, valorx):
    K_list = "".join(mesx)
 
    for i in range(12-len(valorx)):
        valorx.append(0)

    j = 0
    for i in range(12):
        if K_list.find(AAMM[i]) != -1:
            N[i] = valorx[j]
            j = j + 1
    return N

N = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
month_filling(Mes_c, R3X)
R3X = N

N = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
month_filling(Mes_c, R2X)
R2X = N

N = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
month_filling(Mes_c, TotX)
TotX = N

Mes = list(map(mesletras, AAMM))

# RESULTADO:
#   Lista "Mes" contiene los meses en letras para el eje horizontal (x).
#   Lista "R2X" contiene el número de fallas de avisos M2 por cada mes. 
#   Lista "R3X" contiene el número de fallas de avisos M3 por cada mes. 
#   Lista "TotX" contiene el número de fallas totales por cada mes.
#   La variable "promedio" contiene el promedio de fallas en los últimos 12 meses.
#   La variable "total_fallas_R2" contiene el total de fallas M2 en los últimos 12 meses.
#   La variable "total_fallas_R3" contiene el total de fallas M3 en los últimos 12 meses.
#   La variable "desv_standar" contiene la desv. standard del promedio en los últimos 12 meses.

print(Mes)
print(R3X)
print(R2X)
print(TotX)

print(total_fallas_R2)
print(total_fallas_R3)
print(promedio_R2_R3)
print(desv_standard)

