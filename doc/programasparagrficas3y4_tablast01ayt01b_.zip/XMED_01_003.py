# MED_01_003.py .
# Gráfica #3. Cantidad de fallas por planta, últimos 12 meses (GRF.03).


from pathlib import Path
from pandas.core.frame import DataFrame

CURRENT_PATH = Path(__file__)
WORKING_FILE = CURRENT_PATH.parent.joinpath("MED_IW69.csv")

import pandas as pd
import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np

import datetime
from datetime import timedelta

Posic_avisos = pd.read_csv(WORKING_FILE, sep=";")

# Datos para las estadísticas
FechaRef = datetime.date(2021, 10, 27)
MesInic = str(FechaRef.year)[2:] + str(FechaRef.month)

# Calcular PER1 y PER2 (Períodos de 1 y 2 años, AAMM, desde la fecha de referencia.)
mes  = int(MesInic[2:4])
anno = int(MesInic[0:2])
for x in range(0, 2):
    for i in range(1, 12):
        mes = mes - 1
        if mes == 0:
            mes = 12
            anno = anno - 1
    if mes < 10:
        mes = "0" + str(mes)
    else:
        mes = str(mes)
    if x == 0:
        PER1 = str(anno) + mes
    else:
        PER2 = str(anno) + mes 
    mes = int(mes) - 1

# La planta y la fecha de referencias vienen por "Input"
Planta = "DAL"

# Función para determinar el indicador de falla (FI).
def xfi(ifalla, reperc):
    yfalla = ""
    if reperc == 3 or ifalla == "X":
        yfalla = "X"
        return yfalla

# Función para determinar si el aviso está en el período de 1 año.
def xper1(fecha):
    xper = ""
    if fecha <= MesInic and fecha >= PER1:
        xper = "X"
    return xper

# Función que convierte AAMM en letras Mmm y coloca el 'AA si es enero ("Jan").
def mesletras(xmes):
    Mmm = datetime.date(int("20"+xmes[:2]), int(xmes[2:4]), 1).strftime("%b")
    if Mmm == "Jan":
        Mmm = Mmm+"'"+xmes[:2]
    return Mmm

# Crea un nuevo df (Fallas) con campos seleccionados, más uno nuevo ("FI" - indicador
#     de falla, "Planta" y "PER1" - período de 1 año.)

df_fallas = DataFrame(Posic_avisos, columns = ["Aviso", "Ubicac.técnica", 
         "Falla de Equipo", "Inicio avería", "MesInic", "Repercusión", "FI", "Planta",
          "PER1"]) 

# Columna FI
df_fallas["FI"] = df_fallas.apply(lambda x: xfi(x["Falla de Equipo"],
                                         x["Repercusión"]), axis = 1)

# Dejar solo en df_fallas, los avisos de falla (FI = "X")
df_fallas = df_fallas[(df_fallas["FI"]=="X")] 

df_fallas["MesInic"]   = df_fallas["Inicio avería"].apply(lambda x: x[8:] + x[3:5])
df_fallas["PER1"]      = df_fallas["MesInic"].apply(xper1)
df_fallas["Planta"]    = df_fallas["Ubicac.técnica"].apply(lambda x: x[:3])

# print(df_fallas[['Aviso', 'Ubicac.técnica', 'Planta']].head())
df_fallas = df_fallas.drop(['Falla de Equipo', 'FI'], axis = 1)

# Para la planta especificada en la variable "Planta" (que debe venir por input) y 
#   período de 1 año.
df_fallas_planta = df_fallas[(df_fallas["Planta"] == Planta) & (df_fallas["PER1"] == "X")]

# dataframe para la gráfica de fallas por mes (últimos 12 meses).
df_fallas_plot = df_fallas_planta.groupby(["MesInic"]).count()

# Dejando solo las columnas a graficar.
df_fallas_plot = df_fallas_plot.drop(['Ubicac.técnica',  'Inicio avería',
                                      'Repercusión', 'Planta', 'PER1'], axis=1)

# Crea la columna MES a partir del index (ya que este no puede ser usado en la gráfica.)
df_fallas_plot['MES'] = df_fallas_plot.index

df_fallas_plot["MesL"]    = df_fallas_plot["MES"].apply(mesletras)

# Estadísticas generales últimos 12 meses.
promedio = np.round(df_fallas_plot["Aviso"].mean(), 1)
total_fallas = df_fallas_plot["Aviso"].sum()
desv_standard = np.round(df_fallas_plot["Aviso"].std(), 1)


# Esto convierte el contenido de dataframe en listas.
Mes = ""
Fallas = []
for i in range(len(df_fallas_plot)):
    Mes = Mes + df_fallas_plot["MesL"][i] + " "
    Fallas = Fallas + [df_fallas_plot["Aviso"][i]]

Mes = Mes.rstrip().split(" ")

# RESULTADO:
#   Lista "Mes" contiene los meses en letras para el eje horizontal (x).
#   Lista "Fallas" contiene el número de fallas por cada mes. 
#   La variable "promedio" contiene el promedio de fallas en los últimos 12 meses.
#   La variable "total_fallas" contiene el total de fallas en los últimos 12 meses.
#   La variable "desv_standar" contiene la desv. standard del promedio en los últimos 12 meses.

print(Mes)
print(Fallas)
print(promedio)
print(total_fallas)
print(desv_standard)



