# MED_01_T002.py
# Tabla TBL.02A: "Total fallas por mes solicitado."
#       TBL.02B: "Total fallas con paro o limitación de la producción"
# Archivo de datos: MED_IW69.csv (Posiciones de aviso)
#                   MED_IH06.csv (Ubicaciones técnicas)
# Fecha inicio:     31.01.2022.
# Fecha conclusión: 03.02.2022.


##################### Librerías y archivos

from cmath import nan
from pathlib import Path
from numpy import NaN
from pandas.core.frame import DataFrame

CURRENT_PATH = Path(__file__)
WORKING_FILE1 = CURRENT_PATH.parent.joinpath("MED_IW69.csv")
WORKING_FILE2 = CURRENT_PATH.parent.joinpath("MED_IH06.csv")

import pandas as pd
import numpy as np
import datetime
from datetime import timedelta

Posic_avisos = pd.read_csv(WORKING_FILE1, sep=";")
Ubic_téc = pd.read_csv(WORKING_FILE2, sep=";")

# Crear un nuevo df (Fallas) con campos seleccionados.
df_fallas = DataFrame(Posic_avisos, columns = ["Aviso", "Clase de aviso",
         "Ubicac.técnica", "Denominación", "Falla de Equipo", "Inicio avería", 
         "Hora in.avería","MesInic","Repercusión", "Status sistema","Status usuario", 
         "Fin de avería", "Hora fin avería"]) 

# Eliminar los duplicados avisos duplicados en pos_avisos.
df_fallas = df_fallas.drop_duplicates(subset="Aviso")

# Crear un nuevo dataframe con los datos de las ubicaciones técnicas.
UT = DataFrame(Ubic_téc, columns= ['Ubicac.técnica', 'Denominación', 'Perfil catálogo',
                                   'Fabr. Nº-serie'])

# Eliminar las filas sin datos (NaN).
UT = UT.dropna(subset=['Ubicac.técnica'])

##################### Variables generales

# Datos para las estadísticas.
FechaRef = datetime.date(2021, 10, 27)
MesInic = str(FechaRef.year)[2:] + str(FechaRef.month)

# La planta y la fecha de referencias vienen por "Input"
Planta = "DAL"
MesRef = "2110"
MesRef_original = MesRef

# Calcular PER1 y PER2 (Períodos de 1 y 2 años, AAMM, desde la fecha de referencia.)
mes  = int(MesInic[2:4])
anno = int(MesInic[0:2])

for x in range(0, 2):
    for i in range(1, 12):
        mes = mes - 1
        if mes == 0:
            mes = 12
            anno = anno - 1
    if mes < 10:
        mes = "0" + str(mes)
    else:
        mes = str(mes)
    if x == 0:
        PER1 = str(anno) + mes
    else:
        PER2 = str(anno) + mes 
    mes = int(mes) - 1

##################### Funciones

# Función para determinar el indicador de falla (FI).
def xfi(ifalla, reperc):
    yfalla = ""
    if reperc == 3 or ifalla == "X":
        yfalla = "X"
        return yfalla

# Función para determinar si el aviso está en el período de 1 año.
def xper1(fecha):
    xper = ""
    if fecha <= MesInic and fecha >= PER1:
        xper = "X"
    return xper

# Función para determinar si el aviso está en el período de 1 año.
def xper2(fecha):
    xper = ""
    if fecha <= MesInic and fecha >= PER2:
        xper = "X"
    return xper

# Esta función coloca un cero a la izquierda para aquellas horas menores a 10.
def ajuste_hora(hora):
    horax = hora[:2]
    min = hora[3:5]
    if horax[-1] == ":":
        horax = "0" + hora[:1]
        min = hora[2:4]
    hora = horax + min
    return hora

# Función que calcula las horas a partir de los strings F_fin + F_ini
def horasx(datex):
    d2 = datetime.datetime(int(datex[4:8]),int(datex[2:4]),
                           int(datex[0:2]),int(datex[8:10]),int(datex[10:12]))    
    d1 = datetime.datetime(int(datex[16:20]),int(datex[14:16]),
                            int(datex[12:14]),int(datex[20:22]),int(datex[22:24]))
    diff = d2 - d1
    days, seconds = diff.days, diff.seconds
    horas = round(days*24 + seconds /3600, 2)
    return horas

# Función que coloca el guión en un TAG, para efectos de presentación.
def tag_guion(xtag):
    for i in range(0, len(xtag)-1):
        guion = i
        if ord(xtag[i]) < 65:
            #print(xtag[i], ord(xtag[i]))
            break
        guion = guion + 1
        TAGG = xtag[:guion] + '-' + xtag[guion:]
    return TAGG

##################### Cuerpo del programa

# Crear la columnas: "FI"        Failure indicator.
#                    "MesInic"   Año y mes de inicio de la falla, AAMM.
#                    "PER1"      Período 1 año, últimos 12 meses.
#                    "Planta"    Planta a la que corresponde el aviso.

df_fallas["FI"] = df_fallas.apply(lambda x: xfi(x["Falla de Equipo"],
                                         x["Repercusión"]), axis = 1)
df_fallas["MesInic"]   = df_fallas["Inicio avería"].apply(lambda x: x[8:] + x[3:5])
df_fallas["PER1"]      = df_fallas["MesInic"].apply(xper1)
df_fallas["PER2"]      = df_fallas["MesInic"].apply(xper2)
df_fallas["Planta"]    = df_fallas["Ubicac.técnica"].apply(lambda x: x[:3])
df_fallas["Niv_6"]     = df_fallas["Ubicac.técnica"].apply(lambda x: 6 if len(x)>11 else 0)


##################################################################################
# El usuario debe seleccionar el mes de consulta vía input (lista desplegable).  #
#   Por default es el mes de referencia MesRef.                                  #
##################################################################################

# Crear lista con los últimos 24 meses para efectos de entrada por lista desplegable.

mes  = int(MesInic[2:4])
anno = int(MesInic[0:2])
AAMM = ""
cmes = str(mes)

for i in range(1, 25):
    if mes < 10:
       cmes = "0" + str(mes)
    else:
        cmes = str(mes)
    canno = str(anno)
    AAMM = AAMM + canno + cmes + ","
    mes = mes - 1
    if mes == 0:
        mes = 12
        anno = anno - 1
AAMM = AAMM[:-1]
AAMM = AAMM.rstrip().split(",")

MesRef = "2110"

# Texto para el mes, para efectos de título de la tabla.
Desc_mes = {'01': 'Enero', '02': 'Febrero', '03': 'Marzo', '04': 'Abril',
            '05': 'Mayo', '06': 'Junio', '07': 'Julio', '08': 'Agosto',
            '09': 'Septiembre', '10': 'Octubre', '11': 'Noviembre', '12': 'Diciembre'}

if MesRef[:2] == 'YY':
    if MesRef[2:4] == '1A':
        MM = PER1
        Rango = 0
    else:
        MM = PER2
        Rango = 1
    Texto_mes = Desc_mes[MM[2:]]+' 20'+MM[0:2]+' - '+Desc_mes[MesRef_original[2:4]]+' 20'+MesRef_original[:2]
else:
    MM = MesRef
    Rango = 2
    Texto_mes = Desc_mes[MesRef[2:]] + ' 20' + MesRef[0:2]


# Filtrar por planta, período, falla, mes de referencia (MesRef) y nivel 6.

if Rango == 0:
    df_fallas = df_fallas[(df_fallas["Planta"] == Planta) & (df_fallas["FI"] == "X") 
                    & (df_fallas["PER1"] == "X") & (df_fallas["Niv_6"] == 6)]   
elif Rango == 1:
    df_fallas = df_fallas[(df_fallas["Planta"] == Planta) & (df_fallas["FI"] == "X") 
                    & (df_fallas["PER2"] == "X") & (df_fallas["Niv_6"] == 6)]
elif Rango == 2:   
    df_fallas = df_fallas[(df_fallas["Planta"] == Planta) & (df_fallas["FI"] == "X") 
                    & (df_fallas["MesInic"] == MesRef) & (df_fallas["Niv_6"] == 6)]  

# Se podría incluir un "sys.exit" en el caso de que el dataframe resulte vacío.

# Ajustar las horas con un cero a la izquierda para horas menores a 10.
df_fallas["HInic"] = df_fallas["Hora in.avería"].apply(ajuste_hora)

# Crear las columnas F_ini y F_fin como cadena de caracteres ddmmaaaahhmm.
df_fallas["F_ini"] = df_fallas.apply(lambda x: x["Inicio avería"][0:2]  +
                                               x["Inicio avería"][3:5]  +
                                               x["Inicio avería"][6:10] +
                                               x["HInic"], axis = 1)

# Colocar la fecha y hora de inicio de avería en fecha y hora fin de avería cuando
#   esta última sea cero, es decir, cuando la falla todavía esté activa.
# Cuando se reste la (Fecha y hora fin) - (Fecha y hora inicio) dará cero.

# Llenar los valores NaN con cero.
df_fallas = df_fallas.fillna(0)

# Crear un campo transitorio (XHF) para saber cuál aviso originalmente era NaN
df_fallas["XHF"]    = df_fallas["Fin de avería"].apply(lambda x: 0 if x == 0 else 1)

# Si "Fin de avería" es cero, reemplazar con la fecha inicio de avería, sino queda igual.
df_fallas["Fin de avería"] = np.where(df_fallas["Fin de avería"] == 0, 
                                      df_fallas["Inicio avería"], df_fallas["Fin de avería"])

# Si XHF es cero, reemplazar con la hora de inicio de avería, sino queda igual. 
df_fallas["Hora fin avería"] = np.where(df_fallas["XHF"] == 0, 
                                      df_fallas["Hora in.avería"], df_fallas["Hora fin avería"])

# Ajustar las horas con un cero a la izquierda para horas menores a 10.
df_fallas["HFin"]  = df_fallas["Hora fin avería"].apply(ajuste_hora)

# Crear las columnas F_ini y F_fin como cadena de caracteres ddmmaaaahhmm.
df_fallas["F_fin"] = df_fallas.apply(lambda x: x["Fin de avería"][0:2]  +
                                               x["Fin de avería"][3:5]  +
                                               x["Fin de avería"][6:10] +
                                               x["HFin"], axis = 1)   
               
# Calcular la duración del tiempo fuera de servicio (down time).
df_fallas["Dur"] = (df_fallas["F_fin"] + df_fallas["F_ini"]).apply(horasx)

# Separando las duraciones de los R2 y R3.
df_fallas['DurR3'] = df_fallas.apply(lambda x: x['Dur'] if x['Repercusión'] == 3 else 0,
                                               axis = 1 )
df_fallas['DurR2'] = df_fallas.apply(lambda x: x['Dur']*.25 if x['Repercusión'] == 2 else 0,
                                               axis = 1 )

# Separando las fallas R2 y R3.
df_fallas['FIR3'] = df_fallas.apply(lambda x: 1 if x['Repercusión'] == 3 else 0,
                                               axis = 1 )
df_fallas['FIR2'] = df_fallas.apply(lambda x: 1 if x['Repercusión'] == 2 else 0,
                                               axis = 1 )

# Convierte el "X" de FI en 1 (numérico), para efectos de suma.
df_fallas["FI"] = np.where(df_fallas["FI"] == "X", 1, 0)

# Calcular el down time total DurR3 + DurR2 * 0.25 (ya viene multiplicado)
df_fallas["DT"] = df_fallas.apply(lambda x: round(x["DurR3"] + x["DurR2"], 2), axis = 1)

df_fallas["TAG"] = df_fallas["Ubicac.técnica"].apply(lambda x: x[12:])

# Crear un dataframe solo para repercusiones 3 y 2.
df_fallas_R32 = df_fallas[(df_fallas["Repercusión"] > 1)]

df_fallas     = df_fallas.groupby(["Ubicac.técnica"]).sum().reset_index()
df_fallas_R32 = df_fallas_R32.groupby(["Ubicac.técnica"]).sum().reset_index()

# Calcular el down time total DurR3 + DurR2 * 0.25 (ya viene multiplicado)
df_fallas["DT"] = df_fallas.apply(lambda x: round(x["DurR3"] + x["DurR2"], 2), axis = 1)

# Crear la columna TAG.
df_fallas["TAG"] = df_fallas["Ubicac.técnica"].apply(lambda x: x[12:])
df_fallas_R32["TAG"] = df_fallas_R32["Ubicac.técnica"].apply(lambda x: x[12:])

# Colocar el guión al TAG.
df_fallas["TAG"] = df_fallas["TAG"].apply(tag_guion)
df_fallas_R32["TAG"] = df_fallas_R32["TAG"].apply(tag_guion)

# Colcar la denominación de la ubicación técnica mediante un merge con UT.
df_fallas = df_fallas.merge(UT, on = "Ubicac.técnica")
df_fallas_R32 = df_fallas_R32.merge(UT, on = "Ubicac.técnica")

df_fallas['Denominación'] = df_fallas['Denominación'].apply(lambda x: x.ljust(40))
df_fallas['TAG'] = df_fallas['TAG'].apply(lambda x: x.ljust(10))

# Revisa si hay equipos que probablemente estén fuera de servicio (sin fecha fin avería).
df_fallas['PFS'] = df_fallas.apply(lambda x: '' if x['FI'] == x['XHF'] else 'PFS', axis = 1)

# Revisa si hay algún aviso con más de un aviso de falla, y lo marca con una 'X'.
df_fallas['PFS'] = df_fallas.apply(lambda x: 'X' if (x['FI'] - x['XHF']) > 1 else
                                              x['PFS'], axis = 1)

# Denominación y TAG para df_fallas_R32.
df_fallas_R32['Denominación'] = df_fallas_R32['Denominación'].apply(lambda x: x.ljust(40))
df_fallas_R32['TAG'] = df_fallas_R32['TAG'].apply(lambda x: x.ljust(10))


# ORDENAMIENTO, entrada vía input.
#     1. Para ordenar por cantidad de fallas y luego down time.
#     2. Para ordenar por down time y luego por cantidad de fallas.
#  La entrada debe ser vía lista desplegable.

Sort_type = 1

# Ordenar según Sort_type.
if Sort_type == 1:
    df_fallas = df_fallas.sort_values(["FI", "Dur"], ascending = False)
    df_fallas_R32 = df_fallas_R32.sort_values(["FI", "DT"], ascending = False)
else:
    df_fallas = df_fallas.sort_values(["Dur", "FI"], ascending = False)
    df_fallas_R32 = df_fallas_R32.sort_values(["DT", "FI"], ascending = False)


##################### Resultados

### Para "Total fallas" (Tabla TBL.02A)
print(    df_fallas[['TAG', 'Denominación', 'FI', 'Dur', 'XHF', 'PFS']])
Total_fallas    = df_fallas['FI'].sum()
Total_down_time = round(df_fallas['Dur'].sum(),2)
print("\n")
print('Total fallas (mes): ', Total_fallas)
print('Total down time (mes): ', Total_down_time)
print("\n")


### Para "Total fallas con impacto en la producción" (Tabla TBL.02B)
print(Texto_mes)
print(df_fallas_R32[["TAG", "Denominación","FIR3", "FIR2", "FI", "DT"]])
Total_fallas_R32    = df_fallas_R32['FI'].sum()
Total_down_time_R32 = round(df_fallas_R32['DT'].sum(),2)
Total_fallas_R3 = df_fallas_R32['FIR3'].sum()
Total_fallas_R2 = df_fallas_R32['FIR2'].sum()
print("\n")
print('Total fallas con impacto en la producción (mes): ', Total_fallas_R32)
print('Total down time con impacto en la producción (mes): ', Total_down_time_R32)
print('Total fallas R3: ', Total_fallas_R3)
print('Total fallas R2: ', Total_fallas_R2)

##################### Fin del programa

